rootProject.name = "SwordProgression"
